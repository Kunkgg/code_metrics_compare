/* 复用容量 Worker 的紧凑列和索引，为现有 UI 返回有界快照。
 * 阶段1支持文件代码行任务；完整范围、过滤结果与当前页分别计数。 */
const UI = {query: null, overview: null};

function uiPage(items, requested, size) {
  const pages = Math.ceil(items.length / size);
  const page = pages ? Math.max(1, Math.min(Math.trunc(requested || 1), pages)) : 0;
  return {rows: items.slice(Math.max(0, page-1)*size, page*size), total: items.length, page, pages};
}

function uiFile(f) {
  const v=S.files,path=S.paths[f],before=v.bEx[f]?[v.bN[f],v.bR[f],v.bD[f]]:undefined,after=v.cEx[f]?[v.cN[f],v.cR[f],v.cD[f]]:undefined;
  const b=before?.[0]??0,c=after?.[0]??0,delta=c-b,flags=[];
  if(delta>0)flags.push('growth');
  if(delta<0)flags.push('decrease');
  if(!before&&after)flags.push('entered');
  if(before&&!after)flags.push('exited');
  return {id:`file:${path}`,kind:'file',path,name:path.slice(path.lastIndexOf('/')+1),before,after,b,c,delta,flags,changed:delta!==0};
}

function uiAggregate(directory) {
  if(!directory)return {baseline:{value:0,valid:0,count:0},current:{value:0,valid:0,count:0},delta:0};
  const baseline={value:directory.bC,valid:directory.bF,count:directory.bF};
  const current={value:directory.cC,valid:directory.cF,count:directory.cF};
  return {baseline,current,delta:current.value-baseline.value};
}

function uiMatchesNumber(row, condition) {
  if(!condition)return true;
  let value=row[condition.field];
  if(condition.field==='increase'||condition.field==='decrease'){
    if(condition.field==='increase'?row.delta<=0:row.delta>=0)return false;
    value=condition.field==='increase'?row.delta:-row.delta;
  }
  if(value==null)return false;
  return condition.operator==='gte'?value>=condition.value:condition.operator==='lte'?value<=condition.value:value>=condition.value&&value<=condition.upper;
}

function uiFileQuery(state) {
  const scope=state.exactFile||(state.searchScope==='all'?'':state.directory);
  const key=JSON.stringify([scope,!!state.exactFile,state.query,state.numberFilter,state.status,state.sort]);
  if(UI.query?.key!==key){
    let [lo,hi]=scopeRange(scope),aggregate;
    if(state.exactFile){
      const index=S.paths.indexOf(scope);
      [lo,hi]=index<0?[0,0]:[index,index+1];
      const row=index<0?null:uiFile(index);
      aggregate={baseline:{value:row?.b??0,count:row?.before?1:0,valid:row?.before?1:0},current:{value:row?.c??0,count:row?.after?1:0,valid:row?.after?1:0},delta:row?.delta??0};
    }else aggregate=uiAggregate(S.dirs[S.dirByPath.get(scope)]);
    const query=state.query.trim().toLowerCase(),ids=[];
    const counts={all:0,changes:0,growth:0,decrease:0,unchanged:0,entered:0,exited:0,exceptions:0};
    for(let f=lo;f<hi;f++){
      const row=uiFile(f);
      if(query&&!`${row.path} ${row.name}`.toLowerCase().includes(query)||!uiMatchesNumber(row,state.numberFilter))continue;
      const statuses=['all',row.changed?'changes':'unchanged',...row.flags];
      for(const status of statuses)counts[status]++;
      if(statuses.includes(state.status))ids.push(f);
    }
    const [field,direction]=state.sort.split(':'),sign=direction==='asc'?1:-1,v=S.files;
    const value=field==='b'?f=>v.bN[f]:field==='c'?f=>v.cN[f]:f=>v.cN[f]-v.bN[f];
    ids.sort(field==='path'?(a,b)=>(a-b)*sign:(a,b)=>(value(a)-value(b))*sign||a-b);
    UI.query={key,ids,counts,aggregate,scopeCount:hi-lo,scope};
  }
  const cached=UI.query,page=uiPage(cached.ids,state.page,Math.max(1,Math.min(state.pageSize||10,200)));
  return {...page,rows:page.rows.map(uiFile),counts:cached.counts,aggregate:cached.aggregate,scope:cached.scope,scopeCount:cached.scopeCount,exceptionsCount:0,resultExceptionsCount:0};
}

function uiOverview(state) {
  if(!UI.overview){
    const files={growth:{rows:[],total:0},decrease:{rows:[],total:0},unchanged:{rows:[],total:0}};
    // 概览只保留每种方向前8个对象，不复制完整查询行。
    for(let f=0;f<S.F;f++){
      const row=uiFile(f),direction=row.delta>0?'growth':row.delta<0?'decrease':'unchanged',group=files[direction];
      group.total++;
      group.rows.push({...row,fileId:f});
      group.rows.sort((a,b)=>Math.abs(b.delta)-Math.abs(a.delta)||a.fileId-b.fileId);
      if(group.rows.length>8)group.rows.pop();
    }
    const directories=S.dirs.filter(d=>d.p==='include'||/^src\/[^/]+$/.test(d.p));
    const chart=directories.map(d=>({path:d.p,file:false,...uiAggregate(d)}));
    const covered=new Uint8Array(S.F);
    for(const directory of directories){const [lo,hi]=scopeRange(directory.p);covered.fill(1,lo,hi);}
    for(let f=0;f<S.F;f++)if(!covered[f]){
      const row=uiFile(f);
      chart.push({path:row.path,file:true,baseline:{value:row.b,count:row.before?1:0,valid:row.before?1:0},current:{value:row.c,count:row.after?1:0,valid:row.after?1:0},delta:row.delta});
    }
    chart.sort((a,b)=>b.delta-a.delta||(a.path<b.path?-1:a.path>b.path?1:0));
    let maximum=1;for(const row of chart)maximum=Math.max(maximum,Math.abs(row.delta));
    UI.overview={files,chart,maximum};
  }
  const shown=UI.overview.chart.filter(row=>state.overviewChanges.includes(row.delta>0?'growth':row.delta<0?'decrease':'unchanged'));
  return {files:UI.overview.files,chart:{...uiPage(shown,state.chartPage,20),maximum:UI.overview.maximum}};
}

function uiSnapshot(state) {
  if(!S.ready)throw new Error('报告数据尚未就绪');
  if(state.scenario!=='normal')throw new Error('异常样例尚未接入此数据入口，请切回标准样例');
  const unavailable=state.type==='code'?null:'该指标的明细尚未接入当前验证入口，汇总值可在全部指标页查看。';
  const query=unavailable?{rows:[],counts:{},total:null,scopeCount:null,scope:state.directory,page:0,pages:0,exceptionsCount:null,resultExceptionsCount:null}:uiFileQuery(state);
  const overview=uiOverview(state);
  const directory=S.dirs[S.dirByPath.get(state.directory)];
  const directoryPage=uiPage(directory?.cd||[],state.directoryPage,50);
  const directories={...directoryPage,path:state.directory,rows:directoryPage.rows.map(index=>({path:S.dirs[index].p,count:S.dirs[index].cF}))};
  const sides={};
  for(const side of ['baseline','current']){
    const summary=S.meta.summaries[side];
    sides[side]={summary,report:{summary_metrics:summary,detail_metrics:{method_metrics:[S.meta.maxima[side]]}},files:{},methods:[],groups:[],dupfiles:[],folders:{},positions:[]};
  }
  return {
    model:{sides,fileRows:query.rows,methodRows:[],folderRows:[],dirs:[],limited:false},
    transitions:S.meta.thresholdTransitions,ambiguityCount:S.meta.ambiguousMethodCount,
    overview,directories,query,
    selected:unavailable?null:query.rows.find(row=>row.id===state.selected)?.id??query.rows[0]?.id??null,
    unavailable,
  };
}

const capacityMessageHandler=self.onmessage;
self.onmessage=async event=>{
  const message=event.data;
  if(message.op!=='snapshot')return capacityMessageHandler(event);
  const started=performance.now();
  try{
    const payload=uiSnapshot(message.state);
    payload.elapsedWorkerMs=performance.now()-started;
    self.postMessage({type:'result',op:message.op,id:message.id,payload});
  }catch(error){self.postMessage({type:'error',id:message.id,message:error.message});}
};
